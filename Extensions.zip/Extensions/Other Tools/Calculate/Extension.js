function run() {
    return eval("|text|");
};