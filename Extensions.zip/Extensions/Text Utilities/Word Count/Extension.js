function run() {
    return "|text|".split(/\s+/).length;
}