function run() {
    return "|text|".toLowerCase();
}