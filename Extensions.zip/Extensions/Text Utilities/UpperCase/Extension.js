function run() {
    return "|text|".toUpperCase();
}