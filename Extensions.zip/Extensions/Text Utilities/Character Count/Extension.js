function run() {
    return "|text|".length;
}