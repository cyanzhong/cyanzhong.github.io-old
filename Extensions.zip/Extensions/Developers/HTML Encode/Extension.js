function run() {
    var text = "|text|"
    return text.replace(/[^]/g, function(w) {
        return "&#" + text.charCodeAt(0) + ";";
    });
}