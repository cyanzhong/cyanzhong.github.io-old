function run() {
    return encodeURI("|text|");
}