function run() {
    var text = "|text|";
    return text.replace(/&#(\d+);/g, function(match, code) {
        return String.fromCharCode(code);
    });
};