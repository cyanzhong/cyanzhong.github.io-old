function run() {
    return decodeURI("|text|");
}